export interface Customer {
    id: number;
    cusCode: string;
    name: string;
    phone: string;
    address: string;
}
