export interface Bill {
    billCode: string;
    date: Date;
}
