export interface ProductType {
    id : number
    ptypCode: string;
    name: string;
}